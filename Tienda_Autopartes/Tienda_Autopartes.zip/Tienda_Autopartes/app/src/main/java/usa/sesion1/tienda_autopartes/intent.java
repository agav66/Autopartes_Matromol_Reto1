package usa.sesion1.tienda_autopartes;

import android.content.Intent;

public class intent extends Intent {
    public intent(MainActivity mainActivity, Class<MainActivity2> mainActivity2Class) {
    }
}
